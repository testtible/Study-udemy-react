import React, { useContext, useState } from 'react';
import styles from './Cart.module.css';
import Modal from '../UI/Modal';
import CartContext from '../../store/cart-context';
import CartItem from './CartItem';
import Checkout from './Checkout';

const Cart = ({onClose}) => {
    const cartCtx = useContext(CartContext);
    const [isCheckout, setIsCheckout] = useState(false);
    const totalAmount = `$${cartCtx.totalAmount.toFixed(2)}`;
    const hasItems = cartCtx.items.length > 0;

    const cartItemRemoveHandler = (id) => {
        cartCtx.removeItem(id)
    };
    
    const cartItemAddHandler = (item) => {
        cartCtx.addItem({...item, amount: 1});
    };

    const orderHandler = () => {
        setIsCheckout(true);
    };

    const modalActions = (
        <div className={styles.actions}>
            <button className={styles['button--alt']} onClick={onClose}>Close</button>
            {hasItems &&
            <button className={styles.button} onClick={orderHandler}>Order</button>}
        </div>
    )

    const cartItems = (
        <ul className={styles['cart-items']}>
          {cartCtx.items.map((item) => (
            <CartItem
                key={item.id}
                price={item.price}
                amount={item.amount}
                name={item.name}
                onAdd={() => cartItemAddHandler(item)}
                onRemove={() => cartItemRemoveHandler(item.id)}
            />
          ))}
        </ul>
      );

    return (
        <Modal onClose={onClose}>
            {cartItems}
            <div className={styles.total}>
                <span>Total Amount</span>
                <span>{totalAmount}</span>
            </div>
            {isCheckout && <Checkout onCancel={onClose}/>}
            {!isCheckout && modalActions}
        </Modal>
    );
};

export default Cart;